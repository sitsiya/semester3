//
//  MainMenuScene.swift
//  ZombieConga
//
//  Created by MacStudent on 2018-06-04.
//

import Foundation
import SpriteKit

class MainMenuScene: SKScene {
  var playButton = SKSpriteNode()
  var catLady2Button = SKSpriteNode()
  var sunFlowerButton = SKSpriteNode()
  var smallFishButton = SKSpriteNode()
  var bigFishButton = SKSpriteNode()
  var settingButton = SKSpriteNode()
  
  
  
  override func didMove(to view: SKView) {
    
    let background = SKSpriteNode(imageNamed: "MainMenu")
    let playButtonTex = SKTexture(imageNamed: "play")
    let catLady2ButtonTex = SKTexture(imageNamed: "enemy")
    let sunFlowerButtonTex = SKTexture(imageNamed: "sunflower")
    let smallFishButtonTex = SKTexture(imageNamed: "smallFish")
    let bigFishButtonTex = SKTexture(imageNamed: "bigFish")
    
    background.position = CGPoint(x: size.width/2, y: size.height/2)
    addChild(background)
    
    
    
    playButton = SKSpriteNode(texture: playButtonTex)
    playButton.position = CGPoint(x: frame.midX , y: frame.midY)
    playButton.setScale(1.0)
    addChild(playButton)
    
    catLady2Button = SKSpriteNode(texture: catLady2ButtonTex)
    catLady2Button.position = CGPoint(x: 500, y: 1100)
    catLady2Button.setScale(1.0)
    addChild(catLady2Button)
    
    
    sunFlowerButton = SKSpriteNode(texture: sunFlowerButtonTex)
    sunFlowerButton.position = CGPoint(x: 700 , y: 400)
    sunFlowerButton.setScale(0.5)
    addChild(sunFlowerButton)
    
    smallFishButton = SKSpriteNode(texture: smallFishButtonTex)
    smallFishButton.position = CGPoint(x: 1500, y: 1100)
    smallFishButton.setScale(0.5)
    addChild(smallFishButton)
    
    
    bigFishButton = SKSpriteNode(texture: bigFishButtonTex)
    bigFishButton.position = CGPoint(x: 1500 , y: 400)
    bigFishButton.setScale(0.25)
    addChild(bigFishButton)
    
   
    
    
  }
  
  //  func sceneTapped() {
  //    let myScene = GameSceneCatLadyBothSide(size: size)
  //    myScene.scaleMode = scaleMode
  //    let reveal = SKTransition.doorway(withDuration: 1.0)
  //    view?.presentScene(myScene, transition: reveal)
  //  }
  
  override func touchesBegan(_ touches: Set<UITouch>,
                             with event: UIEvent?) {
    if let touch = touches.first{
      let pos = touch.location(in: self)
      let node = self.atPoint(pos)
      
      if node == playButton {
        if let view = view {
          let scene = GameScene (size: size)
          let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
          
          scene.scaleMode = SKSceneScaleMode.aspectFill
          view.presentScene(scene, transition: transition)
        }
      }
      if node == catLady2Button {
        if let view = view {
          let scene = GameScene (size: size)
          let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
          scene.obj = 2
          scene.scaleMode = SKSceneScaleMode.aspectFill
          
          view.presentScene(scene, transition: transition)
        }
      }
      if node == sunFlowerButton {
        if let view = view {
          let scene = GameScene (size: size)
          let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
          scene.obj = 1
          scene.scaleMode = SKSceneScaleMode.aspectFill
          view.presentScene(scene, transition: transition)
        }
      }
      if node == smallFishButton {
        if let view = view {
          let scene = GameScene (size: size)
          let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
          scene.obj = 3
          scene.scaleMode = SKSceneScaleMode.aspectFill
          view.presentScene(scene, transition: transition)
        }
      }
      if node == bigFishButton {
        if let view = view {
          let scene = GameScene (size: size)
          let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
          scene.obj = 4
          scene.scaleMode = SKSceneScaleMode.aspectFill
          view.presentScene(scene, transition: transition)
        }
}
    
  

/*import SpriteKit

class MainMenuScene: SKScene {
  
  override func didMove(to view: SKView) {
    let background = SKSpriteNode(imageNamed: "MainMenu")
    background.position = CGPoint(x: size.width/2, y: size.height/2)
    addChild(background)
  }
  
  func sceneTapped() {
    let myScene = Bigfish(size: size)
    myScene.scaleMode = scaleMode
    let reveal = SKTransition.doorway(withDuration: 1.5)
    view?.presentScene(myScene, transition: reveal)
  }
  
  override func touchesBegan(_ touches: Set<UITouch>,
                             with event: UIEvent?) {
    sceneTapped()
  }
  
}*/
}
}
}
